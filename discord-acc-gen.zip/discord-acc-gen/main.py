
import pyautogui as pg
import os
import random
import time

with open('mail.txt') as f:
    mail = f.readline()
    f.close()

print(" ")
print("mail: " + mail)
print(" ")

os.system("xterm -e firefox --private-window https://discord.com/register?email=" + mail + " &")

random_name = ''.join((random.choice('abcdxyzpqrABCDXYZPQR') for i in range(10)))

time.sleep(15)
pg.hotkey("tab")

pg.typewrite(random_name)

pg.hotkey("tab")

random_pass = ''.join((random.choice('abcdxyzpqrABCDXYZPQR') for i in range(20)))

pg.typewrite(random_pass)

print("name: " + random_name)
print("pass: " + random_pass)

with open("info.txt", 'w') as h:
    h.write("name: " + random_name + "\n" + "pass: " + random_pass)
    print(" ")
    h.close()

pg.hotkey("tab")
pg.typewrite("January")
pg.hotkey("tab")
pg.typewrite("5")
pg.hotkey("tab")
pg.typewrite("1999")
pg.hotkey("tab")
pg.hotkey("tab")
pg.hotkey("space")
pg.hotkey("tab")
pg.hotkey("tab")
pg.hotkey("tab")
pg.hotkey("tab")
pg.hotkey("space")

print("Please Solve Captcha.")
print("After Solving Captcha Press Enter.")

os.system("read name")
