
xterm -e python3 mail.py &
sleep 1
python3 main.py &
